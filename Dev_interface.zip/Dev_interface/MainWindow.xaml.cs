﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media.Imaging;
using Microsoft.Win32;
using TagLib;

namespace Dev_interface
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private bool isPlaying = false;
        private bool isMuted = false;   
        
        public MainWindow()
        {
            InitializeComponent();
            LoadSongs();
            LoadVideos();
        }
        private void Previous_Click(object sender, MouseButtonEventArgs e)
        {
            try
            {
                if (listBoxSongs.Items.Count > 0)
                {
                    int selectedIndex = listBoxSongs.SelectedIndex;
                    int previousIndex = (selectedIndex - 1 + listBoxSongs.Items.Count) % listBoxSongs.Items.Count; // Calcula o índice da música anterior, garantindo que seja circular
                    listBoxSongs.SelectedIndex = previousIndex;
                }
                else
                {
                    MessageBox.Show("No songs available.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error selecting previous song: {ex.Message}");
            }
        }

        private void Next_Click(object sender, MouseButtonEventArgs e)
        {
            try
            {
                if (listBoxSongs.Items.Count > 0)
                {
                    int selectedIndex = listBoxSongs.SelectedIndex;
                    int nextIndex = (selectedIndex + 1) % listBoxSongs.Items.Count; // Calcula o índice da próxima música, garantindo que seja circular
                    listBoxSongs.SelectedIndex = nextIndex;
                }
                else
                {
                    MessageBox.Show("No songs available.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error selecting next song: {ex.Message}");
            }
        }

        private void PlayButton_Click(object sender, MouseButtonEventArgs e)
        {
            try
            {
                if (listBoxSongs.Items.Count > 0)
                {
                    if (listBoxSongs.SelectedItem == null)
                    {
                        listBoxSongs.SelectedIndex = 0; // Seleciona a primeira música da lista
                    }
                    mediaElement.Play();
                    isPlaying = true;
                    UpdatePlaybackIcons();
                }
                else
                {
                    MessageBox.Show("No songs available to play.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error playing media: {ex.Message}");
            }
        }

        private void PauseButton_Click(object sender, MouseButtonEventArgs e)
        {
            try
            {
                mediaElement.Pause();
                isPlaying = false;
                UpdatePlaybackIcons();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error pausing media: {ex.Message}");
            }
        }
        private void UpdatePlaybackIcons()
        {
            playButton.Visibility = isPlaying ? Visibility.Collapsed : Visibility.Visible;
            pauseButton.Visibility = isPlaying ? Visibility.Visible : Visibility.Collapsed;
        }
        private void VolumeSlider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            mediaElement.Volume = e.NewValue;
        }
        private void MuteButton_Click(object sender, MouseButtonEventArgs e)
        {
            try
            {
                mediaElement.IsMuted = !mediaElement.IsMuted;
                isMuted = true;
                UpdateMutekIcons();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error muting media: {ex.Message}");
            }
        }

        private void PlaySoundButton_Click(object sender, MouseButtonEventArgs e)
        {
            try
            {
                mediaElement.IsMuted = !mediaElement.IsMuted;
                isMuted = false;
                UpdateMutekIcons();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error unmuting media: {ex.Message}");
            }
        }

        private void UpdateMutekIcons()
        {
            MuteButton.Visibility = isMuted ? Visibility.Collapsed : Visibility.Visible;
            PlaySoundButton.Visibility = isMuted ? Visibility.Visible : Visibility.Collapsed;
        }
        private void LoadSongs()
        {
            try
            {
                string directoryPath = "C:\\Users\\Marcos\\Documents\\extensao\\Dev_interface\\Musics";
                string[] songFiles = Directory.GetFiles(directoryPath);

                foreach (string songFile in songFiles)
                {
                    listBoxSongs.Items.Add(Path.GetFileName(songFile));
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading songs: {ex.Message}");
            }
        }
        private void listBoxSongs_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
             try
            {
                string selectedSong = listBoxSongs.SelectedItem as string;
                if (selectedSong != null)
                {
                    string directoryPath = @"C:\Users\Marcos\Documents\extensao\Dev_interface\Musics";
                    string songPath = Path.Combine(directoryPath, selectedSong);

                    mediaElement.Source = new Uri("file://" + songPath);
                    mediaElement.Play();
                    isPlaying = true;
                    UpdatePlaybackIcons();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}");
            }
        }
        private void LoadVideos()
        {
            try
            {
                string directoryPath = "C:\\Users\\Marcos\\Documents\\extensao\\Dev_interface\\Videos";
                string[] videoFiles = Directory.GetFiles(directoryPath);

                foreach (string videoFile in videoFiles)
                {
                    listBoxVideos.Items.Add(Path.GetFileName(videoFile));
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading videos: {ex.Message}");
            }
        }

        private void listBoxVideos_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
             try
            {
                string selectedVideo = listBoxVideos.SelectedItem as string;
                if (selectedVideo != null)
                {
                    string directoryPath = @"C:\Users\Marcos\Documents\extensao\Dev_interface\Videos";
                    string videoPath = Path.Combine(directoryPath, selectedVideo);

                    mediaElement.Source = new Uri("file://" + videoPath);
                    mediaElement.Play();
                    isPlaying = true;
                    UpdatePlaybackIcons();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}");
            }
        }

        private void Music_Click(object sender, MouseButtonEventArgs e)
        {
            List_Music.Visibility = Visibility.Visible;
            Menu.Visibility = Visibility.Collapsed;            
            List_Video.Visibility = Visibility.Collapsed;
        }
        private void Video_Click(object sender, MouseButtonEventArgs e)
        {
            List_Video.Visibility = Visibility.Visible;
            Menu.Visibility = Visibility.Collapsed;
            List_Music.Visibility = Visibility.Collapsed;
        }
        private void Menu_Click(object sender, MouseButtonEventArgs e)
        {
            Menu.Visibility = Visibility.Visible;
            List_Music.Visibility = Visibility.Collapsed;            
            List_Video.Visibility = Visibility.Collapsed;
        }
    }
}
